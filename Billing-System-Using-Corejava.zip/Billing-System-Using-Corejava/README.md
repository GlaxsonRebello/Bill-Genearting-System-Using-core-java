# WalMart Billing system
## Requirements
1. JTattoo.jar File

## Usage
1. Clone the repository or download it
2. Navigate to the directory containing the java files
